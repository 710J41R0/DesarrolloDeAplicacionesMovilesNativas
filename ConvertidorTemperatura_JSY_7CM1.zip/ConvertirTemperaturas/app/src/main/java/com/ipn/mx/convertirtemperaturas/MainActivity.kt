package com.ipn.mx.convertirtemperaturas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {
    private lateinit var btnResolver : Button
    private lateinit var txtGrados : EditText
    private lateinit var rbtnGradosC1 : RadioButton
    private lateinit var rbtnGradosK1 : RadioButton
    private lateinit var rbtnGradosF1 : RadioButton
    private lateinit var rbtnGradosC2 : RadioButton
    private lateinit var rbtnGradosK2 : RadioButton
    private lateinit var rbtnGradosF2 : RadioButton
    private lateinit var lblResultado : TextView
    var tmp : Double = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initView()
        btnResolver.setOnClickListener() {
            if(txtGrados.text.toString().isEmpty()) lblResultado.setText("Blank")
            else {
                tmp = txtGrados.text.toString().toDouble()
1
                if(rbtnGradosC1.isChecked) {
                    if (rbtnGradosF2.isChecked) lblResultado.setText(String.format("%.3f", centigradosAFarenheit(tmp)) + " F")
                    else if (rbtnGradosK2.isChecked) lblResultado.setText(String.format("%.3f", centigradosAKelvin(tmp)) + " K")
                    else noCambios()
                }else if(rbtnGradosK1.isChecked){
                    if(rbtnGradosC2.isChecked) lblResultado.setText(String.format("%.3f", kelvinACentigrados(tmp)) + " C")
                    else if(rbtnGradosF2.isChecked) lblResultado.setText(String.format("%.3f", kelvinAFarenheit(tmp)) + " F")
                    else noCambios()
                }else{
                    if(rbtnGradosC2.isChecked) lblResultado.setText(String.format("%.3f", farenheitACentigrados(tmp)) + " C")
                    else if(rbtnGradosK2.isChecked) lblResultado.setText(String.format("%.3f", farenheitAKelvin(tmp)) + " K")
                    else noCambios()
                }

            }

        }
    }

    private fun initView() {
        btnResolver = findViewById<Button>(R.id.btnResolver)
        txtGrados = findViewById<EditText>(R.id.txtGrados)
        rbtnGradosC1 = findViewById<RadioButton>(R.id.rbtnGradosC1)
        rbtnGradosK1 = findViewById<RadioButton>(R.id.rbtnGradosK1)
        rbtnGradosF1 = findViewById<RadioButton>(R.id.rbtnGradosF1)
        rbtnGradosC2 = findViewById<RadioButton>(R.id.rbtnGradosC2)
        rbtnGradosK2 = findViewById<RadioButton>(R.id.rbtnGradosK2)
        rbtnGradosF2 = findViewById<RadioButton>(R.id.rbtnGradosF2)
        lblResultado = findViewById<TextView>(R.id.lblResultado)
        lblResultado.setText("")
    }

    private fun limpiarResultados() {
        lblResultado.setText("")
    }

    private fun noCambios() {
        limpiarResultados()
        lblResultado.setText("NC")
    }

    private fun centigradosAFarenheit(tmp : Double) : Double {
        limpiarResultados()
        var resul : Double = (tmp * 9 / 5) + 32
        return resul
    }

    private fun centigradosAKelvin(tmp : Double) : Double {
        limpiarResultados()
        var resul : Double = tmp +  273
        return resul
    }

    private fun kelvinACentigrados(tmp : Double) : Double {
        limpiarResultados()
        var resul : Double = tmp -  273
        return resul
    }

    private fun kelvinAFarenheit(tmp : Double) : Double {
        limpiarResultados()
        var resul : Double = centigradosAFarenheit(kelvinACentigrados(tmp))
        return resul
    }

    private fun farenheitACentigrados(tmp : Double) : Double {
        limpiarResultados()
        var resul : Double = (tmp - 32) * 5 / 9
        return resul
    }

    private fun farenheitAKelvin(tmp : Double) : Double {
        limpiarResultados()
        var resul : Double = centigradosAKelvin(((tmp - 32) * 5 / 9))
        return resul
    }


}