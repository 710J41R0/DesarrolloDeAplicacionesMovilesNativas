package com.market.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.market.screens.CartScreen
import com.market.screens.MovieDetailScreen
import com.market.screens.ProfileScreen
import com.market.screens.ShopScreen


@Composable
fun AppNavigation(navController: NavHostController = rememberNavController()) {

    NavHost(
        navController = navController,
        startDestination = AppScreens.ShopScreen.route
    ){
        composable(AppScreens.ShopScreen.route){
            ShopScreen(navController)
        }
        composable(route = AppScreens.CartScreen.route){
            CartScreen(navController)
        }
        composable(route = AppScreens.ProfileScreen.route){
            ProfileScreen(navController)
        }

        composable(route = "${AppScreens.MovieDetailScreen.route}/{movieId}") { backStackEntry ->
            val movieId = backStackEntry.arguments?.getString("movieId")?.toIntOrNull()
            if (movieId != null) {
                MovieDetailScreen(movieId = movieId)
            } else {
                // Manejar error - el movieId no fue pasado correctamente.
            }
        }

    }


}