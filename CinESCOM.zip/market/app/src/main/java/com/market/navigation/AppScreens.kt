package com.market.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.ui.graphics.vector.ImageVector

sealed class AppScreens (
    val route: String,
    val title: String,
    val icon: ImageVector
    ) {
    object ProfileScreen : AppScreens(
        route ="profile_screen",
        title = "Mi Cuenta",
        icon = Icons.Default.Person
    )
    object CartScreen : AppScreens(
        route = "cart_screen",
        title = "Carrito",
        icon = Icons.Default.ShoppingCart
    )

    object ShopScreen : AppScreens(
        route = "shop_screen",
        title = "Cartelera",
        icon = Icons.Default.PlayArrow
    )

    object MovieDetailScreen : AppScreens(
        route = "movie_detail_screen",
        title = "Detalles de la Pelicula",
        icon = Icons.Default.PlayArrow
    )
}

