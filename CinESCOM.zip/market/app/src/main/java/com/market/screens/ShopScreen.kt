package com.market.screens

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberImagePainter
import com.market.R
import com.market.model.Movie
import com.market.model.MovieDB
import com.market.model.MovieDBClient
import com.market.model.MovieDBResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.concurrent.thread

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopScreen(
    navController: NavController,
    modifier: Modifier = Modifier
    ) {
    var movieDB by remember { mutableStateOf<MovieDB?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val apiKey: String = stringResource(id = R.string.api_key)

    LaunchedEffect(key1 = Unit){
        try{
            val response = withContext(Dispatchers.IO) {
                MovieDBClient.service.getMovies(apiKey).execute().body()
            }
            movieDB = response // Actualizamos los datos con la respuesta.
            isLoading = false // Dejamos de mostrar la barra de progreso.

        }catch (e: Exception){
            Log.d("ShopScreen", "Exception: $e")
            error = e.message
            isLoading = false
        }
    }
    when {
        isLoading -> {
            Box(modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
            ) {
                CircularProgressIndicator()
            }

        }
        error != null -> {
            Text(text = "Error: $error") // Mostrar el error si hay uno.
        }

        else -> {
            // Mostrar los datos cuando están cargados.
            val movieList = movieDB?.results ?: return
            LazyColumn {
                items(movieList) { movie ->
                    // Aquí es donde diseñas cada elemento de la lista.
                    MovieItem(movie = movie) {
                        navController.navigate("movie_detail_screen/${movie.id}")
                    }
                }
            }
        }
    }
}

@Composable
fun MovieItem(movie: Movie, onClick: () -> Unit){
    Card(
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = MaterialTheme.shapes.medium,
    ) {
        Row(modifier = Modifier.padding(4.dp)) {
            Image(
                painter = rememberImagePainter(data = "https://image.tmdb.org/t/p/w185/${movie.poster_path}"),
                contentDescription = "${movie.original_title} poster",
                modifier = Modifier
                    .size(100.dp)
                    .clip(MaterialTheme.shapes.small)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(
                modifier = Modifier.padding(vertical = 16.dp),

            ) {
                Text(
                    text = movie.title,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = movie.release_date,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Text(
                    text = "Rating: ${movie.vote_average}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}



