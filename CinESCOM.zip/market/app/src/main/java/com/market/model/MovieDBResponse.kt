package com.market.model

class MovieDBResponse {

}
