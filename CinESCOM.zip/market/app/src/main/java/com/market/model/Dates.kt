package com.market.model

data class Dates(
    val maximum: String,
    val minimum: String
)