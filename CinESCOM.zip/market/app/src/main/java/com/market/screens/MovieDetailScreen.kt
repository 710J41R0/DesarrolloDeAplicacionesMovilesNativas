package com.market.screens

import android.util.Log
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role.Companion.Image
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.market.R
import com.market.model.Movie
import com.market.model.MovieDB
import com.market.model.MovieDBClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconToggleButton
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import coil.compose.rememberImagePainter
import com.google.firebase.firestore.FirebaseFirestore


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MovieDetailScreen(movieId: Int){
    var movie by remember { mutableStateOf<Movie?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val apiKey: String = stringResource(id = R.string.api_key)

    val db = FirebaseFirestore.getInstance()


    LaunchedEffect(key1 = Unit){
        try{
            val response = withContext(Dispatchers.IO) {
                MovieDBClient.service.getMovieDetail(movieId, apiKey).execute().body()
            }
            movie = response // Actualizamos los datos con la respuesta.
            isLoading = false // Dejamos de mostrar la barra de progreso.

        }catch (e: Exception){
            Log.d("ShopScreen", "Exception: $e")
            error = e.message
            isLoading = false
        }
    }
    when {
        isLoading -> {
            Box(modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
            ) {
                CircularProgressIndicator()
            }

        }
        error != null -> {
            Text(text = "Error: $error") // Mostrar el error si hay uno.
        }
        else -> {
            // Mostrar los datos cuando están cargados.
            val movieDetail = movie?: return
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Text(text = movieDetail.title)
                        }
                    )
                }
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {


                    Image(
                        painter = rememberImagePainter(data = "https://image.tmdb.org/t/p/w185/${movieDetail.poster_path}"),
                        contentDescription = "Movie poster",
                        modifier = Modifier
                            .height(200.dp)
                            .fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = movieDetail.title,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = movieDetail.release_date,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

//                    RatingBar(
//                        modifier = Modifier.align(Alignment.CenterHorizontally),
//                        value = (movieDetail.vote_average / 2).toFloat(), // scale it down to 5 stars
//                        onValueChange = {},
//                        enabled = false,
//                        size = 26.dp,
//                        spacing = 4.dp
//                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = movieDetail.overview,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Counter()

                    Button(onClick = {
                        db.collection("users").document("user1").set(hashMapOf(
                            "name" to "Ada",
                            "last" to "Lovelace",
                            "born" to 1815
                        ))

                    }) {
                        Text("Comprar boletos")
                    }
                }


            }
        }
    }
}


@Composable
fun Counter() {
    var count by remember { mutableStateOf(0) }
    var price = 45

    Column() {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Precio: \$ ${price}",
                style = MaterialTheme.typography.bodyMedium,
            )
        }


        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Button(onClick = { if (count > 0) count-- }, modifier = Modifier.padding(end = 8.dp)) {
                Text("-")
            }

            Text(
                text = count.toString(),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier
                    .padding(8.dp)
                    .width(50.dp)
                    .align(Alignment.CenterVertically),
                textAlign = TextAlign.Center

            )

            Button(onClick = { count++ }, modifier = Modifier.padding(start = 8.dp)) {
                Text("+")
            }
        }

        Row(
            modifier = Modifier
                .padding(vertical = 16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center

        ) {
            Text(
                text = "Total: \$ ${price*count}",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

//
//@Composable
//fun RatingBar(
//    modifier: Modifier = Modifier,
//    value: Float,
//    onValueChange: (Float) -> Unit,
//    enabled: Boolean,
//    size: Dp,
//    spacing: Dp
//) {
//    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
//        for (i in 1..5) {
//            IconToggleButton(
//                checked = i <= value,
//                onCheckedChange = { if (enabled) onValueChange(i.toFloat()) },
//                modifier = Modifier.size(size).padding(end = spacing)
//            ) {
//                Icon(
//                    painter = if (i <= value) painterResource(id = R.drawable.ic_filled_star) else painterResource(id = R.drawable.ic_empty_star),
//                    contentDescription = null
//                )
//            }
//        }
//    }
//}

@Preview
@Composable
fun PreviewMovieDetailScreen(){
    MovieDetailScreen(movieId = 1)
}