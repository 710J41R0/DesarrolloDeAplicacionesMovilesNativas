package com.ipn.mx.listafrases

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private var adapter : ListaAdapter? = null
    private lateinit var recyclerView : RecyclerView
    private var listaDeFrases: ArrayList<String> = ArrayList()
    //lateinit var txtLista: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recyclerView = findViewById(R.id.rvwContenido)
        initRecyclerView()
        getSensores()
        // When an item is touched, show its attribute -> nombre
        adapter?.setOnclickItem {
            Toast.makeText(this, "Nombre: ${it}", Toast.LENGTH_LONG).show()
        }

    }
    fun getSensores() {
        // Get Array of sensores
        listaDeFrases.add("En una ocasión la muerte tuvo una experiencia cercana a Chuck Norris")
        listaDeFrases.add("Chuck Norris no cumple años. Es el tiempo el que cumple Chuck Norris")
        listaDeFrases.add("Chuck Norris no duerme. Espera")
        listaDeFrases.add("Chuck Norris es la razón por la que Wally se esconde")
        listaDeFrases.add("En un salón hay 1.200 objetos con los que Chuck Norris podría matarte. Incluido el propio salón")
        listaDeFrases.add("Chuck Norris murió hace 10 años. Solo que la muerte no ha tenido el valor de decírselo")
        listaDeFrases.add("Si Chuck Norris llega tarde, más le vale al tiempo ir despacio")
        listaDeFrases.add("Chuck Norris dona sangre frecuentemente a la Cruz Roja. Solo que nunca es la suya")
        listaDeFrases.add("Antes de que naciera Chuck Norris, el Mar Muerto vivía")
        listaDeFrases.add("Un eclipse de sol es sencillamente que Chuck Norris no encuentra sus gafas de sol")
        listaDeFrases.add("Chuck Norris es capaz de ganar al ajedrez jugando con las negras y solo con el rey")
        listaDeFrases.add("Cuando Chuck Norris pela una cebolla es la cebolla la que llora")
        // Set Asistente
        adapter?.agregarItems(listaDeFrases)
    }
    // Fun that inits the recycle view
    private fun initRecyclerView(){
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ListaAdapter()
        recyclerView.adapter = adapter
    }
}