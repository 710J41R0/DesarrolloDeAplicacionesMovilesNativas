package com.ipn.mx.listafrases

import android.graphics.drawable.Drawable
import android.hardware.Sensor
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ListaAdapter : RecyclerView.Adapter<ListaAdapter.ListaViewHolder>() {
    // Init objects which are going to be used after
    private var fraseList : List<String> = ArrayList()
    private var onClickItem : ((String) -> Unit)? = null

    fun agregarItems(items: ArrayList<String>){
        this.fraseList = items
        notifyDataSetChanged()
    }

    // When an item is touched on screen
    fun setOnclickItem(callback: (String) -> Unit){
        this.onClickItem = callback
    }

    // When it's created, charge the card_item intead of default layout
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ListaViewHolder (
        LayoutInflater.from(parent.context).inflate(R.layout.frase_item, parent, false)
    )

    // To get attributes when an item is touched
    override fun onBindViewHolder(holder: ListaViewHolder, position: Int) {
        val ast = fraseList[position]
        holder.bindView(ast)
        holder.itemView.setOnClickListener{ onClickItem?.invoke(ast) }
    }

    // Pre-implemented method, just returns size of list
    override fun getItemCount(): Int {
        return fraseList.size
    }

    // Help to get data from item and setting it again to 'form' fields
    class ListaViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        // Get components (in this case: Fields)
        private var imagen : ImageView = view.findViewById<ImageView>(R.id.tvImgSensor)
        private var frase = view.findViewById<TextView>(R.id.tvFrase)
        private var autor = view.findViewById<TextView>(R.id.tvAutor)

        // Set values to components
        fun bindView(ssr : String) {
            imagen.setImageResource(R.drawable.chuck)
            frase.text = "Frase: " + ssr
            autor.text = "Autor: Chuck Norris"
        }
    }
}