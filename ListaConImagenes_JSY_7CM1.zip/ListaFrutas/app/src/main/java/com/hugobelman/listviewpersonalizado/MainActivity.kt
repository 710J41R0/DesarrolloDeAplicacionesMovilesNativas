package com.escom.listafrutas

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val a1 = Producto("AGUACATE", 45.0, "Rico Aguacate.", R.drawable.aguacate)
        val a2 = Producto("CEREZA", 60.0, "Rica Cereza.", R.drawable.cereza)
        val a3 = Producto("CIRUELA", 34.0, "Rica Ciruela.", R.drawable.ciruela)
        val a4 = Producto("COCO", 23.0, "Rico Coco.", R.drawable.coco)
        val a5 = Producto("DURAZNO", 50.0, "Rico Durazno.", R.drawable.durazno)
        val a6 = Producto("FRESA", 80.0, "Rica Fresa.", R.drawable.fresa)
        val a7 = Producto("GRANADA", 20.0, "Rica Granada.", R.drawable.granada)
        val a8 = Producto("GUAYABA", 27.0, "Rica Guayaba.", R.drawable.guayaba)
        val a9 = Producto("MANGO", 32.0, "Rico Mango.", R.drawable.mango)
        val a10 = Producto("MANZANA", 45.0, "Rica Manzana.", R.drawable.manzana)
        val a11 = Producto("MELON", 18.0, "Rico Melon.", R.drawable.melon)
        val a12 = Producto("MORAS", 34.0, "Ricas Moras.", R.drawable.moras)
        val a13 = Producto("NARANJA", 15.0, "Rica Naranja.", R.drawable.naranja)
        val a14 = Producto("PERA", 20.0, "Rica Pera.", R.drawable.pera)
        val a15 = Producto("PIÑA", 28.0, "Rica Piña.", R.drawable.pina)
        val a16 = Producto("SANDIA", 12.0, "Rica Sandia.", R.drawable.sandia)
        val a17 = Producto("UVAS", 70.0, "Ricas Uvas.", R.drawable.uvas)

        val listaProductos = listOf(a4, a3, a1, a17,a2,a8,a5,a16,a6,a13,a15,a7,a14,a11,a10,a12,a11,a9)

        val adapter = ProductosAdapter(this, listaProductos)

        lista.adapter = adapter

        lista.setOnItemClickListener { parent, view, position, id ->
            val intent = Intent(this, ProductoActivity::class.java)
            intent.putExtra("producto", listaProductos[position])
            startActivity(intent)
        }
    }
}
