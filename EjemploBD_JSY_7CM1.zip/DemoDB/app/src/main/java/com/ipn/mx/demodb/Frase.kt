package com.ipn.mx.demodb

class Frase {
    var id : Int = 0
    var frase : String = ""
    var autor : String = ""

    constructor(frase : String, autor : String){
        this.frase = frase
        this.autor = autor
    }
}