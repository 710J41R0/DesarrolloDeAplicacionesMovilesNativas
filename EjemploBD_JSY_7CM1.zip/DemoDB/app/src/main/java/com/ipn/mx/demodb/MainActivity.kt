package com.ipn.mx.demodb

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    lateinit var frase: EditText
    lateinit var autor: EditText
    lateinit var btnGuardar: Button
    lateinit var btnListado: Button
    lateinit var tvDatos: TextView
    lateinit var texto: String


    lateinit var db: SQLiteHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Jalamos los elementos
        frase = findViewById(R.id.txtFrase)
        autor = findViewById(R.id.txtAutor)
        tvDatos = findViewById(R.id.tvDatos)
        texto = ""

        btnGuardar = findViewById(R.id.btnGuardar)
        btnListado = findViewById(R.id.btnListado)

        // Asignamos los 'ESCUCHA'
        db = SQLiteHelper(this)

        btnGuardar.setOnClickListener(){
            val laFrase = frase.text.toString()
            val elAutor = autor.text.toString()

            // Creamos al instancia de la clase frase
            val f = Frase(laFrase, elAutor)

            val almacenado = db.create(f)

            if(almacenado == true){
                Toast.makeText(this, "Se ha almacenado correctamente el dato", Toast.LENGTH_SHORT).show()
                frase.text.clear()
                autor.text.clear()
            }
        } // btnGuardar

        btnListado.setOnClickListener(){
            tvDatos.setText("")
            Toast.makeText(this, "Listado", Toast.LENGTH_SHORT).show()
            muestraTabla()

            // MOnada, si no funciona lo corrigen
            val cursor = db.readAll() // Si esta vacío retorna un -1, eso sieve para validar el vacío
            val sb = StringBuilder()
            while (cursor.moveToNext()){
                sb.append("Frase: ").append(cursor.getString(1)).append("\n")
                sb.append("Autor: ").append(cursor.getString(2)).append("\n")
            }

            val alertDialog = AlertDialog.Builder(this)
            alertDialog.setTitle("Listado ")
            alertDialog.setMessage(sb.toString())
            alertDialog.show()

        }//btnListado

    }// end onCreate

    fun muestraTabla(){
        val cursor = db.readAll()
        val numeroFilas : Int = cursor.count
        cursor.moveToFirst()
        for(i in 1 .. numeroFilas){
            var id : Int = cursor.getInt(0)
            var frase : String = cursor.getString(1)
            var autor : String = cursor.getString(2)
            texto += "\n $id, $frase, $autor\n"
            cursor.moveToNext()
        }// endFor
        tvDatos.append(texto)

    }

}

// TextUtils -> clase que resuelve las validaciones de campos para un formualrio