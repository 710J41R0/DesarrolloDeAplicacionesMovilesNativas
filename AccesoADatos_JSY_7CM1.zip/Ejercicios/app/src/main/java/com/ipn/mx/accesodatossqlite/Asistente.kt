package com.ipn.mx.accesodatossqlite

class Asistente {
    var idAsistente: Int
    var nombreAsistente: String
    var paternoAsistente: String
    var maternoAsistente: String
    var emailAsistente: String
    var idEvento: Int

    constructor(idAsistente: Int,
                nombreAsistente: String,
                paternoAsistente: String,
                maternoAsistente: String,
                emailAsistente: String,
                idEvento: Int
    ){
        this.idAsistente = idAsistente
        this.nombreAsistente = nombreAsistente
        this.paternoAsistente = paternoAsistente
        this.maternoAsistente = maternoAsistente
        this.emailAsistente = emailAsistente
        this.idEvento = idEvento
    }
}

