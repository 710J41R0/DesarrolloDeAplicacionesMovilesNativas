package com.ipn.mx.accesodatossqlite

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AsistenteManagement : AppCompatActivity() {
    // Get components wich user interact with
    private lateinit var nombreAsistente : EditText
    private lateinit var paternoAsistente : EditText
    private lateinit var maternoAsistente : EditText
    private lateinit var emailAsistente : EditText
    private lateinit var idEvento : EditText

    private lateinit var btnAgregar : Button
    private lateinit var btnVisualizar : Button
    private lateinit var btnActualizar : Button

    // Create instances to help us do back proccessing
    private lateinit var sqliteHelper : SQLiteHelper
    private lateinit var recyclerView : RecyclerView
    private var adapter : AsistenteAdapter? = null
    private var ast : Asistente? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_asistente_management)

        // Init components
        initView()
        initRecyclerView()
        sqliteHelper = SQLiteHelper(this)

        // Asociate methods to their listeners
        btnAgregar.setOnClickListener{ agregarAsistente() }
        btnVisualizar.setOnClickListener{ getAsistentes() }
        btnActualizar.setOnClickListener{ actualizarAsistente() }

        // When an item is touched, show its attribute -> nombre
        adapter?.setOnclickItem {
            Toast.makeText(this, it.nombreAsistente, Toast.LENGTH_SHORT).show()
            nombreAsistente.setText(it.nombreAsistente)
            paternoAsistente.setText(it.paternoAsistente)
            maternoAsistente.setText(it.maternoAsistente)
            emailAsistente.setText(it.emailAsistente)
            idEvento.setText(it.idEvento.toString())
            ast = it
        }

        // When an item is touched on its delete button, show y/n dialog to confirm it
        adapter?.setOnclickDeleteItem {
            eliminarAsistente(it.idAsistente)
        }
    }

    // Fun to get all Asistente
    private fun getAsistentes(){
        // Get Array of Asistente
        val asistenteList = sqliteHelper.getAllAsistente()
        Log.e("pppp", "${asistenteList.size}") // Just for test
        // Set Asistente
        adapter?.agregarItems(asistenteList)
    }

    // Fun to create Asistente
    private fun agregarAsistente(){
        // Get values
        val nombre = nombreAsistente.text.toString()
        val paterno = paternoAsistente.text.toString()
        val materno = maternoAsistente.text.toString()
        val email = emailAsistente.text.toString()
        val idEvento = idEvento.text.toString()

        // Verify if they're no empty (although we can set more validations)
        if(nombre.isEmpty() || paterno.isEmpty() || materno.isEmpty() || email.isEmpty() || idEvento.isEmpty()){
            Toast.makeText(this, "Por favor no dejes campos vacíos", Toast.LENGTH_SHORT).show()
        }else{
            // Try to insert
            val ast = Asistente(0, nombre, paterno, materno, email, idEvento.toInt())
            val status = sqliteHelper.insertAsistente(ast)

            // Verify result and show response
            if(status > -1){
                Toast.makeText(this, "Asistente agregado", Toast.LENGTH_SHORT).show()
                clearEditText()
                getAsistentes()
            }else{
                Toast.makeText(this, "Falló agregar Asistente", Toast.LENGTH_SHORT).show()
                clearEditText()
            }
        }
    }

    // Fun to update Asistente
    private fun actualizarAsistente(){
        // Get values
        val nombre = nombreAsistente.text.toString()
        val paterno = paternoAsistente.text.toString()
        val materno = maternoAsistente.text.toString()
        val email = emailAsistente.text.toString()
        val idEvento = idEvento.text.toString().toInt()

        // Verify if data changed
        if(nombre == ast?.nombreAsistente && paterno == ast?.paternoAsistente
            && materno == ast?.maternoAsistente && email == ast?.emailAsistente
            && idEvento == ast?.idEvento) {
            Toast.makeText(this, "No se han cambiado datos para actualizar",
                Toast.LENGTH_SHORT).show()
            return
        }

        // Veryfy nulls
        if(ast == null){
            Toast.makeText(this, "NULL", Toast.LENGTH_SHORT)
                .show()
            return
        }

        // Create an instance with modified data and try to update
        val asis = Asistente(ast!!.idAsistente, nombre, paterno, materno, email, idEvento)
        val status = sqliteHelper.actualizarAsistente(asis)

        // Verify ststus and generate a response
        if(status > -1){
            clearEditText()
            getAsistentes()
            Toast.makeText(this, "Asistente actualizado con éxitp", Toast.LENGTH_SHORT)
                .show()
        }else{
            Toast.makeText(this, "Ha ocurrido una excepcion al actualizar Asistente",
                Toast.LENGTH_SHORT).show()
        }
    }

    // Fun to delete Asistente
    private fun eliminarAsistente(idAsistente : Int){
        // Set a verification factos (y/n dialog)
        val builder = AlertDialog.Builder(this)
        builder.setMessage("¿Estas seguro de querer eliminar el Asistente?")
        builder.setCancelable(true)

        // If 'YES', delete event
        builder.setPositiveButton("Si"){ dialog, _->
            sqliteHelper.eliminarAsistentePorId(idAsistente)
            getAsistentes()
            dialog.dismiss()
        }

        // If 'NO', do nothing
        builder.setNegativeButton("No"){ dialog, _->
            dialog.dismiss()
        }

        // Show dialog
        val alert = builder.create()
        alert.show()
    }

    // Fun clear fields on UI
    private fun clearEditText(){
        nombreAsistente.setText("")
        paternoAsistente.setText("")
        maternoAsistente.setText("")
        emailAsistente.setText("")
        idEvento.setText("")
    }

    // Fun that inits the recycle view
    private fun initRecyclerView(){
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AsistenteAdapter()
        recyclerView.adapter = adapter
    }

    // Fun that inits the view (main)
    private fun initView(){
        nombreAsistente = findViewById(R.id.txtAsistenteNombre)
        paternoAsistente = findViewById(R.id.txtAsistentePaterno)
        maternoAsistente = findViewById(R.id.txtAsistenteMaterno)
        emailAsistente = findViewById(R.id.txtAsistenteEmail)
        idEvento = findViewById(R.id.txtAsistenteIdEvento)
        btnAgregar = findViewById(R.id.btnAsistenteAgregar)
        btnVisualizar = findViewById(R.id.btnAsistenteVisualizar)
        btnActualizar = findViewById(R.id.btnAsistenteActualizar)
        recyclerView = findViewById(R.id.rvwAsistenteContenido)
    }
}