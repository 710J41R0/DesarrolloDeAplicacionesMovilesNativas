package com.ipn.mx.accesodatossqlite

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Adapter
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class EventoManagement : AppCompatActivity() {
    // Get components wich user interact with
    private lateinit var nombreEvento : EditText
    private lateinit var descripcionEvento : EditText
    private lateinit var fechaEvento : EditText
    private lateinit var btnAgregar : Button
    private lateinit var btnVisualizar : Button
    private lateinit var btnActualizar : Button

    // Create instances to help us do back proccessing
    private lateinit var sqliteHelper : SQLiteHelper
    private lateinit var recyclerView : RecyclerView
    private var adapter : EventoAdapter? = null
    private var evt : Evento? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_evento_management)

        // Init components
        initView()
        initRecyclerView()
        sqliteHelper = SQLiteHelper(this)

        // Asociate methods to their listeners
        btnAgregar.setOnClickListener{ agregarEvento() }
        btnVisualizar.setOnClickListener{ getEventos() }
        btnActualizar.setOnClickListener{ actualizarEvento() }

        // When an item is touched, show its attribute -> nombre
        adapter?.setOnclickItem {
            Toast.makeText(this, it.nombreEvento, Toast.LENGTH_SHORT).show()
            nombreEvento.setText(it.nombreEvento)
            descripcionEvento.setText(it.descripcionEvento)
            fechaEvento.setText(it.fechaEvento)
            evt = it
        }

        // When an item is touched on its delete button, show y/n dialog to confirm it
        adapter?.setOnclickDeleteItem {
            eliminarEvento(it.idEvento)
        }

    }

    // Fun to get all Eventos
    private fun getEventos(){
        // Get Array of Evento
        val eventoList = sqliteHelper.getAllEvento()
        Log.e("pppp", "${eventoList.size}") // Just for test
        // Set Eventos
        adapter?.agregarItems(eventoList)
    }

    // Fun to create Evento
    private fun agregarEvento(){
        // Get values
        val nombre = nombreEvento.text.toString()
        val descripcion = descripcionEvento.text.toString()
        val fecha = fechaEvento.text.toString()

        // Verify if they're no empty (although we can set more validations)
        if(nombre.isEmpty() || descripcion.isEmpty() || fecha.isEmpty()){
            Toast.makeText(this, "Por favor no dejes campos vacíos", Toast.LENGTH_SHORT).show()
        }else{
            // Try to insert
            val evt = Evento(0, nombre, descripcion, fecha)
            val status = sqliteHelper.insertEvento(evt)

            // Verify result and show response
            if(status > -1){
                Toast.makeText(this, "Evento agregado", Toast.LENGTH_SHORT).show()
                clearEditText()
                getEventos()
            }else{
                Toast.makeText(this, "Falló agregar Evento", Toast.LENGTH_SHORT).show()
                clearEditText()
            }
        }
    }

    // Fun to update Evento
    private fun actualizarEvento(){
        // Get values
        val nombre = nombreEvento.text.toString()
        val descripcion = descripcionEvento.text.toString()
        val fecha = fechaEvento.text.toString()

        // Verify if data changed
        if(nombre == evt?.nombreEvento && descripcion == evt?.descripcionEvento && fecha == evt?.fechaEvento) {
            Toast.makeText(this, "No se han cambiado datos para actualizar", Toast.LENGTH_SHORT)
                .show()
            return
        }

        // Veryfy nulls
        if(evt == null){
            Toast.makeText(this, "NULL", Toast.LENGTH_SHORT)
                .show()
            return
        }

        // Create an instance with modified data and try to update
        val evto = Evento(evt!!.idEvento, nombre, descripcion, fecha)
        val status = sqliteHelper.actualizarEvento(evto)

        // Verify ststus and generate a response
        if(status > -1){
            clearEditText()
            getEventos()
            Toast.makeText(this, "Evento actualizado con éxitp", Toast.LENGTH_SHORT)
                .show()
        }else{
            Toast.makeText(this, "Ha ocurrido una excepcion al actualizar evento", Toast.LENGTH_SHORT).show()
        }
    }

    // Fun to delete Evento
    private fun eliminarEvento(idEvento : Int){
        // Set a verification factos (y/n dialog)
        val builder = AlertDialog.Builder(this)
        builder.setMessage("¿Estas seguro de querer eliminar el evento?")
        builder.setCancelable(true)

        // If 'YES', delete event
        builder.setPositiveButton("Si"){ dialog, _->
            sqliteHelper.eliminarEventoPorId(idEvento)
            getEventos()
            dialog.dismiss()
        }

        // If 'NO', do nothing
        builder.setNegativeButton("No"){ dialog, _->
            dialog.dismiss()
        }

        // Show dialog
        val alert = builder.create()
        alert.show()
    }

    // Fun clear fields on UI
    private fun clearEditText(){
        nombreEvento.setText("")
        descripcionEvento.setText("")
        fechaEvento.setText("")
    }

    // Fun that inits the recycle view
    private fun initRecyclerView(){
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = EventoAdapter()
        recyclerView.adapter = adapter
    }

    // Fun that inits the view (main)
    private fun initView(){
        nombreEvento = findViewById(R.id.txtEventoNombre)
        descripcionEvento = findViewById(R.id.txtEventoDescripcion)
        fechaEvento = findViewById(R.id.txtEventoFecha)
        btnAgregar = findViewById(R.id.btnEventoAgregar)
        btnVisualizar = findViewById(R.id.btnEventoVisualizar)
        btnActualizar = findViewById(R.id.btnEventoActualizar)
        recyclerView = findViewById(R.id.rvwEventoContenido)
    }
}