package com.ipn.mx.accesodatossqlite

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AsistenteAdapter: RecyclerView.Adapter<AsistenteAdapter.AsistenteViewHolder>() {
    // Init objects which are going to be used after
    private var asistenteList : ArrayList<Asistente> = ArrayList()
    private var onClickItem : ((Asistente) -> Unit)? = null
    private var onClickDeleteItem : ((Asistente) -> Unit)? = null

    /* Class methosd, some native, some hand-implemented */
    // Updating Evento's list and notificating changes
    fun agregarItems(items: ArrayList<Asistente>){
        this.asistenteList = items
        notifyDataSetChanged()
    }

    // When an item is touched on screen
    fun setOnclickItem(callback: (Asistente) -> Unit){
        this.onClickItem = callback
    }

    // When item's delete button is touched on screen
    fun setOnclickDeleteItem(callback: (Asistente) -> Unit){
        this.onClickDeleteItem = callback
    }

    // When it's created, charge the card_item intead of default layout
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = AsistenteViewHolder (
        LayoutInflater.from(parent.context).inflate(R.layout.card_items_asistente, parent, false)
    )

    // To get attributes when an item is touched
    override fun onBindViewHolder(holder: AsistenteViewHolder, position: Int) {
        val ast = asistenteList[position]
        holder.bindView(ast)
        holder.itemView.setOnClickListener{ onClickItem?.invoke(ast) }
        holder.btnEliminar.setOnClickListener{ onClickDeleteItem?.invoke(ast) }
    }

    // Pre-implemented method, just returns size of list
    override fun getItemCount(): Int {
        return asistenteList.size
    }

    // Help to get data from item and setting it again to 'form' fields
    class AsistenteViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        // Get components (in this case: Fields)
        private var idAsistente = view.findViewById<TextView>(R.id.tvIdAsistente)
        private var nombreAsistente = view.findViewById<TextView>(R.id.tvNombreAsistente)
        private var paternoAsistente = view.findViewById<TextView>(R.id.tvPaternoAsistente)
        private var maternoAsistente = view.findViewById<TextView>(R.id.tvMaternoAsistente)
        private var emailAsistente = view.findViewById<TextView>(R.id.tvEmailAsistente)
        private var idEvento = view.findViewById<TextView>(R.id.tvIdEventoAsistente)

        var btnEliminar = view.findViewById<Button>(R.id.btnEliminarAsistente)

        // Set values to components
        fun bindView(ast : Asistente) {
            idAsistente.text = ast.idAsistente.toString()
            nombreAsistente.text = ast.nombreAsistente.toString()
            paternoAsistente.text = ast.paternoAsistente.toString()
            maternoAsistente.text = ast.maternoAsistente.toString()
            emailAsistente.text = ast.emailAsistente.toString()
            idEvento.text = ast.idEvento.toString()
        }
    }
}