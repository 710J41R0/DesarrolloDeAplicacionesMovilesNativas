package com.ipn.mx.accesodatossqlite

class ModelAsistente {
}