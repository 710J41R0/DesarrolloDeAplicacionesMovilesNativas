package com.ipn.mx.accesodatossqlite

import android.content.Context
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import java.util.*
import kotlin.collections.ArrayList

class SQLiteHelper (context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME,null, DATABASE_VERSION) {

    // Constantes
    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "dbAccesoDatos.db"
        private const val TBL_EVENTO = "EVENTOS"
        private const val ID_EVENTO = "idEvento"
        private const val NOMBRE_EVENTO = "nombreEvento"
        private const val DESCRIPCION_EVENTO = "descripcionEvento"
        private const val FECHA_EVENTO = "fechaEvento"

        private const val TBL_ASISTENTE = "Asistentes"
        private const val ID_ASISTENTE = "idAsistente"
        private const val NOMBRE_ASISTENTE = "nombreAsistente"
        private const val PATERNO_ASISTENTE = "paternoAsistente"
        private const val MATERNO_ASISTENTE = "maternoAsistente"
        private const val EMAIL_ASISTENTE = "emailAsistente"
        private const val ID_EVENTO_ASISTENTE = "idEvento"

    }

    // ##################################################################################################################################################################
    // ########################################################################## Init DataBase #########################################################################
    // ##################################################################################################################################################################

    // Al crear
    override fun onCreate(db: SQLiteDatabase?) {
        // Create table Evento
        val sqlEvento = "create table " + TBL_EVENTO +
                " (idEvento integer primary key autoincrement," +
                " nombreEvento text," +
                " descripcionEvento text," +
                " fechaEvento text)"
        db?.execSQL(sqlEvento)

        // Create table Asistente
        val sqlAsistente = "CREATE TABLE " + TBL_ASISTENTE+ " (idAsistente integer primary key autoincrement," +
                " nombreAsistente text," +
                " paternoAsistente text," +
                " maternoAsistente text," +
                " emailAsistente text," +
                " idEvento integer," +
                "FOREIGN KEY ("+ ID_EVENTO_ASISTENTE +") REFERENCES Eventos("+ ID_EVENTO +"))"
        db?.execSQL(sqlAsistente)

    }

    // Al modificar
    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        // Dropping tables if they exists
        db?.execSQL("DROP TABLE IF EXISTS " + TBL_EVENTO)
        db?.execSQL("DROP TABLE IF EXISTS " + TBL_ASISTENTE)
        onCreate(db)
    }


    // ##################################################################################################################################################################
    // ######################################################################### CRUD Evento ############################################################################
    // ##################################################################################################################################################################

    /* ****** Create Evento ****** */
    fun insertEvento(evento : Evento): Long{
        // Get DB
        val db = this.writableDatabase

        // Get a container and set -> {Field, Value}
        val contentValues = ContentValues()
        contentValues.put(NOMBRE_EVENTO, evento.nombreEvento)
        contentValues.put(DESCRIPCION_EVENTO, evento.descripcionEvento)
        contentValues.put(FECHA_EVENTO, evento.fechaEvento.toString())

        // Apply Query and get the submission result (wich is returned)
        val resultado : Long = db.insert(TBL_EVENTO, null, contentValues)
        db.close()
        return resultado
    }

    /* ****** Retrieve all Evento ****** */
    fun getAllEvento() : ArrayList<Evento> {
        // Data Structure to save registers
        val eventoList: ArrayList<Evento> = ArrayList()

        // Get fromat of query and the DB
        val selectQuery = "SELECT * FROM $TBL_EVENTO"
        val db = this.readableDatabase

        // Get all the data in a cursor (if empty, return no data)
        val cursor : Cursor?
        try {
            cursor = db.rawQuery(selectQuery, null)
        } catch (e: Exception){
            e.printStackTrace()
            db.execSQL(selectQuery)
            return ArrayList()
        }

        // Attributes from Evento (class)
        var idEvento: Int
        var nombreEvento: String
        var descripcionEvento: String
        var fechaEvento: String

        // Set data obtained from cursor to an ArrayList of Evento (class) To make it more easy to access
        if(cursor.moveToFirst()){
            do{
                idEvento = cursor.getInt(cursor.getColumnIndex("idEvento"))
                nombreEvento = cursor.getString(cursor.getColumnIndex(NOMBRE_EVENTO))
                descripcionEvento = cursor.getString(cursor.getColumnIndex(DESCRIPCION_EVENTO))
                fechaEvento = cursor.getString(cursor.getColumnIndex(FECHA_EVENTO))

                val evt = Evento(idEvento, nombreEvento, descripcionEvento, fechaEvento)
                eventoList.add(evt)
            }while (cursor.moveToNext())
        }
        return eventoList
    }

    /* ****** Update Evento ****** */
    fun actualizarEvento(evt : Evento) : Int {
        // Get DB
        val db = this.writableDatabase

        // Get a container and set -> {Field, Value}
        val contentValues = ContentValues()
        contentValues.put(ID_EVENTO, evt.idEvento)
        contentValues.put(NOMBRE_EVENTO, evt.nombreEvento)
        contentValues.put(DESCRIPCION_EVENTO, evt.descripcionEvento)
        contentValues.put(FECHA_EVENTO, evt.fechaEvento)

        // Execute query and return -1 if and exception occurs, otherwise return 1
        try{
            db.update(TBL_EVENTO, contentValues, "idEvento=${evt.idEvento}", null)
            db.close()
        }catch (e: Exception){
            e.printStackTrace()
            db.close()
            return -1
        }
        return 1
    }

    /* ****** Delete Evento ****** */
    fun eliminarEventoPorId(idEvento : Int) : Int{
        // Get DB
        val db = this.writableDatabase

        // Excecute query and return its result
        val succes = db.delete(TBL_EVENTO, "idEvento=$idEvento", null)
        db.close()
        return succes
    }


    // ##################################################################################################################################################################
    // ####################################################################### CRUD Asistente ###########################################################################
    // ##################################################################################################################################################################

    /* ****** Create Asistente ****** */
    fun insertAsistente(asistente : Asistente): Long{
        // Get DB
        val db = this.writableDatabase

        // Get a container and set -> {Field, Value}
        val contentValues = ContentValues()
        contentValues.put(NOMBRE_ASISTENTE, asistente.nombreAsistente)
        contentValues.put(PATERNO_ASISTENTE, asistente.paternoAsistente)
        contentValues.put(MATERNO_ASISTENTE, asistente.maternoAsistente)
        contentValues.put(EMAIL_ASISTENTE, asistente.emailAsistente)
        contentValues.put(ID_EVENTO_ASISTENTE, asistente.idEvento)

        // Apply Query and get the submission result (wich is returned)
        val resultado : Long = db.insert(TBL_ASISTENTE, null, contentValues)
        db.close()
        return resultado
    }

    /* ****** Retrieve all Asistente ****** */
    fun getAllAsistente() : ArrayList<Asistente> {
        // Data Structure to save registers
        val asistenteList: ArrayList<Asistente> = ArrayList()

        // Get fromat of query and the DB
        val selectQuery = "SELECT * FROM $TBL_ASISTENTE"
        val db = this.readableDatabase

        // Get all the data in a cursor (if empty, return no data)
        val cursor : Cursor?
        try {
            cursor = db.rawQuery(selectQuery, null)
        } catch (e: Exception){
            e.printStackTrace()
            db.execSQL(selectQuery)
            return ArrayList()
        }

        // Attributes from Evento (class)
        var idAsistente: Int
        var nombreAsistente: String
        var paternoAsistente: String
        var maternoAsistente: String
        var emailAsistente: String
        var idEvento: Int

        // Set data obtained from cursor to an ArrayList of Evento (class) To make it more easy to access
        if(cursor.moveToFirst()){
            do{
                idAsistente = cursor.getInt(cursor.getColumnIndex(ID_ASISTENTE))
                nombreAsistente = cursor.getString(cursor.getColumnIndex(NOMBRE_ASISTENTE))
                paternoAsistente = cursor.getString(cursor.getColumnIndex(PATERNO_ASISTENTE))
                maternoAsistente = cursor.getString(cursor.getColumnIndex(MATERNO_ASISTENTE))
                emailAsistente = cursor.getString(cursor.getColumnIndex(EMAIL_ASISTENTE))
                idEvento = cursor.getInt(cursor.getColumnIndex(ID_EVENTO_ASISTENTE))

                val ast = Asistente(idAsistente, nombreAsistente, paternoAsistente, maternoAsistente, emailAsistente, idEvento)
                asistenteList.add(ast)
            }while (cursor.moveToNext())
        }
        return asistenteList
    }

    /* ****** Update Asistente ****** */
    fun actualizarAsistente(ast : Asistente) : Int {
        // Get DB
        val db = this.writableDatabase

        // Get a container and set -> {Field, Value}
        val contentValues = ContentValues()
        contentValues.put(ID_ASISTENTE, ast.idAsistente)
        contentValues.put(NOMBRE_ASISTENTE, ast.nombreAsistente)
        contentValues.put(PATERNO_ASISTENTE, ast.paternoAsistente)
        contentValues.put(MATERNO_ASISTENTE, ast.maternoAsistente)
        contentValues.put(EMAIL_ASISTENTE, ast.emailAsistente)
        contentValues.put(ID_EVENTO_ASISTENTE, ast.idEvento)

        // Execute query and return -1 if and exception occurs, otherwise return 1
        try{
            db.update(TBL_ASISTENTE, contentValues, "idAsistente=${ast.idAsistente}", null)
            db.close()
        }catch (e: Exception){
            e.printStackTrace()
            db.close()
            return -1
        }
        return 1
    }

    /* ****** Delete Asistente ****** */
    fun eliminarAsistentePorId(idAsistente : Int) : Int{
        // Get DB
        val db = this.writableDatabase

        // Excecute query and return its result
        val succes = db.delete(TBL_ASISTENTE, "idAsistente=${idAsistente}", null)
        db.close()
        return succes
    }


}