package com.ipn.mx.accesodatossqlite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    // Get components on screen
    private lateinit var manageEvento: Button
    private lateinit var manageAsistente: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Asociating components to variables
        manageEvento = findViewById<Button>(R.id.btnAdminEvento)
        manageAsistente = findViewById<Button>(R.id.btnAdminAsistente)

        // Adding listeners, each one displays its correspondent screen
        manageEvento.setOnClickListener(){
            val i = Intent(this, EventoManagement::class.java)
            startActivity(i)
        }
        manageAsistente.setOnClickListener(){
            val i = Intent(this, AsistenteManagement::class.java)
            startActivity(i)
        }
    }
}