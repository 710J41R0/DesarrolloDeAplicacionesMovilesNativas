package com.ipn.mx.accesodatossqlite

import android.content.Context
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase

class ModelEvento (context: Context) :
    SQLiteOpenHelper(context, "dbAccesoDatos.db",null, 1) {
    // Al crear
    override fun onCreate(db: SQLiteDatabase?) {
        val sql = "create table Eventos(idEvento integer primary key autoincrement," +
                " nombreEvento text," +
                " descripcionEvento text," +
                " fechaEvento DateOnly)"
        db?.execSQL(sql)
    }

    // Al modificar
    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        db?.execSQL("DROP TABLE IF EXISTS Eventos")
        onCreate(db)
    }

    // Create evento
    fun createEvento(evento : Evento): Boolean{
        val db = writableDatabase

        val contentValues = ContentValues()
        contentValues.put("nombreEvento", evento.nombreEvento)
        contentValues.put("descripcionEvento", evento.descripcionEvento)
        contentValues.put("fechaEvento", evento.fechaEvento.toString())

        val resultado : Long = db.insert("Eventos", null, contentValues)
        return (resultado != (-1).toLong())
    }

    // Retrieve evento
    /*fun retrieveEvento(evento : Evento): Boolean{
        val db = writableDatabase
        val cursor = db.rawQuery("DELETE FROM Eventos WHERE idEvento = $evento.idEvento", null)
        return (resultado != (-1).toLong())
    }*/

    // Retrieve all
    fun retrieveAllEvento() : Cursor {
        val db = writableDatabase
        val cursor = db.rawQuery("SELECT * FROM Eventos", null)
        return  cursor
    }
}