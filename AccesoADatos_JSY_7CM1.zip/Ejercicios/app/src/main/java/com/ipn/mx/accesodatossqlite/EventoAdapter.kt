package com.ipn.mx.accesodatossqlite

import android.view.LayoutInflater
import android.view.ScrollCaptureCallback
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EventoAdapter: RecyclerView.Adapter<EventoAdapter.EventoViewHolder>(){
    // Init objects which are going to be used after
    private var eventoList : ArrayList<Evento> = ArrayList()
    private var onClickItem : ((Evento) -> Unit)? = null
    private var onClickDeleteItem : ((Evento) -> Unit)? = null

    /* Class methosd, some native, some hand-implemented */
    // Updating Evento's list and notificating changes
    fun agregarItems(items: ArrayList<Evento>){
        this.eventoList = items
        notifyDataSetChanged()
    }

    // When an item is touched on screen
    fun setOnclickItem(callback: (Evento) -> Unit){
        this.onClickItem = callback
    }

    // When item's delete button is touched on screen
    fun setOnclickDeleteItem(callback: (Evento) -> Unit){
        this.onClickDeleteItem = callback
    }

    // When it's created, charge the card_item intead of default layout
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = EventoViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.card_items_evento, parent, false)
    )

    // To get attributes when an item is touched
    override fun onBindViewHolder(holder: EventoViewHolder, position: Int) {
        val evt = eventoList[position]
        holder.bindView(evt)
        holder.itemView.setOnClickListener{ onClickItem?.invoke(evt) }
        holder.btnEliminar.setOnClickListener{ onClickDeleteItem?.invoke(evt) }

    }

    // Pre-implemented method, just returns size of list
    override fun getItemCount(): Int {
        return eventoList.size
    }

    // Help to get data from item and setting it again to 'form' fields
    class EventoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        // Get components (in this case: Fields)
        private var id = view.findViewById<TextView>(R.id.tvId)
        private var nombre = view.findViewById<TextView>(R.id.tvNombre)
        private var desripcion = view.findViewById<TextView>(R.id.tvDescripcion)
        private var fecha = view.findViewById<TextView>(R.id.tvFecha)

        var btnEliminar = view.findViewById<Button>(R.id.btnEliminar)

        // Set values to components
        fun bindView(evt : Evento) {
            id.text = evt.idEvento.toString()
            nombre.text = evt.nombreEvento.toString()
            desripcion.text = evt.descripcionEvento.toString()
            fecha.text = evt.fechaEvento.toString()
        }
    }

}