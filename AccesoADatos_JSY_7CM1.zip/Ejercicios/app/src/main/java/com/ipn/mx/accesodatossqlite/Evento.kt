package com.ipn.mx.accesodatossqlite

class Evento {
    var idEvento: Int
    var nombreEvento: String
    var descripcionEvento: String
    var fechaEvento: String

    constructor(
        idEvento: Int,
        nombreEvento: String,
        descripcionEvento: String,
        fechaEvento: String
    ){
        this.idEvento = idEvento
        this.nombreEvento = nombreEvento
        this.descripcionEvento = descripcionEvento
        this.fechaEvento = fechaEvento
    }

}
