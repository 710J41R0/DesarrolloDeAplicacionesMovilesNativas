package com.ipn.mx

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val numero: EditText = findViewById(R.id.txtNumero)
        val btn: Button = findViewById(R.id.btnCalcular)
        val resultado: TextView = findViewById(R.id.lblResultado)
        val imagen : ImageView = findViewById(R.id.imgCont)
        imagen.setImageResource(R.drawable.calculos)
        btn.setOnClickListener(){
            var num: Int = numero.text.toString().toInt()
            var myResult: Long = 1
            for (i in 1..num) {
                myResult *= i.toLong()
            }
            resultado.setText("Resultado:" + myResult.toString())
            Toast.makeText(this, "Resultado:" + myResult.toString(), Toast.LENGTH_SHORT).show()
        }
    }
}