package com.ipn.mx.sensores

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private var adapter : SensorAdapter? = null
    private lateinit var recyclerView : RecyclerView
    //lateinit var txtLista: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recyclerView = findViewById(R.id.rvwContenido)
        initRecyclerView()
        getSensores()
        // When an item is touched, show its attribute -> nombre
        adapter?.setOnclickItem {
            Toast.makeText(this, "Nombre: ${it.name}, Version: ${it.version}", Toast.LENGTH_LONG).show()
        }

    }
    fun getSensores() {
        // Get Array of sensores
        var sm: SensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        var listaDeSensores: List<Sensor> = sm.getSensorList(Sensor.TYPE_ALL)
        // Set Asistente
        adapter?.agregarItems(listaDeSensores)
    }
    // Fun that inits the recycle view
    private fun initRecyclerView(){
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = SensorAdapter()
        recyclerView.adapter = adapter
    }
}