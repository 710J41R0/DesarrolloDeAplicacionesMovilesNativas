package com.ipn.mx.sensores

import android.graphics.drawable.Drawable
import android.hardware.Sensor
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SensorAdapter : RecyclerView.Adapter<SensorAdapter.SensorViewHolder>() {
    // Init objects which are going to be used after
    private var sensorList : List<Sensor> = ArrayList()
    private var onClickItem : ((Sensor) -> Unit)? = null

    fun agregarItems(items: List<Sensor>){
        this.sensorList = items
        notifyDataSetChanged()
    }

    // When an item is touched on screen
    fun setOnclickItem(callback: (Sensor) -> Unit){
        this.onClickItem = callback
    }

    // When it's created, charge the card_item intead of default layout
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = SensorViewHolder (
        LayoutInflater.from(parent.context).inflate(R.layout.sensor_item, parent, false)
    )

    // To get attributes when an item is touched
    override fun onBindViewHolder(holder: SensorViewHolder, position: Int) {
        val ast = sensorList[position]
        holder.bindView(ast)
        holder.itemView.setOnClickListener{ onClickItem?.invoke(ast) }
    }

    // Pre-implemented method, just returns size of list
    override fun getItemCount(): Int {
        return sensorList.size
    }

    // Help to get data from item and setting it again to 'form' fields
    class SensorViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        // Get components (in this case: Fields)
        private var imagen : ImageView = view.findViewById<ImageView>(R.id.tvImgSensor)
        private var nombre = view.findViewById<TextView>(R.id.tvNombre)
        private var tipo = view.findViewById<TextView>(R.id.tvTipo)
        private var vendor = view.findViewById<TextView>(R.id.tVendor)
        private var version = view.findViewById<TextView>(R.id.tvVersion)
        private var resolucion = view.findViewById<TextView>(R.id.tvResolución)

        // Set values to components
        fun bindView(ssr : Sensor) {
            imagen.setImageResource(R.drawable.phone_sensor)
            nombre.text = "Name: " + ssr.name.toString()
            tipo.text = "Type: " + ssr.type.toString()
            vendor.text = "Vendor: " + ssr.vendor.toString()
            version.text = "Version: " + ssr.version.toString()
            resolucion.text = "Resolution: " + ssr.resolution.toString()
        }
    }
}