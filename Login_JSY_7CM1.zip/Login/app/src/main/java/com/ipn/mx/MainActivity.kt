package com.ipn.mx

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var usuario: EditText
    lateinit var password: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        usuario = findViewById(R.id.usuario)
        password = findViewById(R.id.password)
        val btn: Button = findViewById(R.id.btnIngresar)
        val chk: CheckBox = findViewById(R.id.chkRecuerdame)
        val intent: Intent = Intent(this, Acceso::class.java)
        val sharedPreferences = getSharedPreferences("MISDATOS", Context.MODE_PRIVATE)

        val flag = sharedPreferences.getString("flag", "")
        val nombreDeUsuario = sharedPreferences.getString("nombreDeUsuario", "")
        val claveDeUsuario = sharedPreferences.getString("claveDeUsuario", "")
        val editor = sharedPreferences.edit()

        cargaPreferencias()

            btn.setOnClickListener(){

            if(!usuario.text.isEmpty() and !password.text.toString().isEmpty()){
                if(chk.isChecked){
                    editor.putString("flag", "1")
                    editor.putString("nombreDeUsuario", usuario.text.toString())
                    editor.putString("claveDeUsuario", password.text.toString())
                    // Dejamos seteado que persista los valores
                    editor.apply()
                }else{
                    editor.putString("flag", "0")
                    editor.putString("nombreDeUsuario", "")
                    editor.putString("claveDeUsuario", "")
                    editor.apply()
                    var datos : Bundle = Bundle()
                    datos.putString("usuario", usuario.text.toString())
                    datos.putString("contrasena", password.text.toString())
                    intent.putExtras(datos)
                }
                    startActivity(intent)
            }else{
                Toast.makeText(this, "Credenciales incorrectas", Toast.LENGTH_SHORT).show()

            }

        }
    }
    fun cargaPreferencias(){
        val sharedPreferences = getSharedPreferences("MISDATOS", Context.MODE_PRIVATE)
        val nombreDeUsuario = sharedPreferences.getString("nombreDeUsuario", "")
        val claveDeUsuario = sharedPreferences.getString("claveDeUsuario", "")

        if(!nombreDeUsuario.toString().equals("") and !claveDeUsuario.toString().equals("")) {
            usuario.setText(nombreDeUsuario)
            password.setText(claveDeUsuario)
        }

    }
}