package com.ipn.mx

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Acceso : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_acceso)


        val lblUser = findViewById<TextView>(R.id.lblUser)
        val lblPass = findViewById<TextView>(R.id.lblPass)
        val sharePreference = getSharedPreferences("MISDATOS", Context.MODE_PRIVATE)

        val flag = sharePreference.getString("flag", "").toString()
        val nombreUsuario = sharePreference.getString("nombreDeUsuario", "").toString()
        val claveUsuario = sharePreference.getString("claveDeUsuario", "").toString()


        if(flag.equals("0")){
            val datosNR : Bundle? = intent.extras
            val name : String? = datosNR!!.getString("usuario")
            val pass : String? = datosNR!!.getString("contrasena")
            lblUser.setText(name)
            lblPass.setText(pass)
        }else{
            lblUser.setText(nombreUsuario)
            lblPass.setText(claveUsuario)
        }
    }
}